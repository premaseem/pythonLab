
def func1(s):
    st = s + "folder2.mymodule.func1"
    print(st)
    return st