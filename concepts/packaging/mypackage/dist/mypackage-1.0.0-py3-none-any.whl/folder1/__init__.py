__all__ = ["func1"]

from .mymodule import *
