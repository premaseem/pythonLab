__all__ = ["func2"]

from .mymodule import *
