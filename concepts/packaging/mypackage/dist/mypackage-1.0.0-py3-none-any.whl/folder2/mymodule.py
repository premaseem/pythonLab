
def func2(s):
    st = s + "folder1.mymodule.func1"
    print(st)
    return st